﻿using System;
using System.Collections.Generic;
using System.IO;

namespace TaxCalculationLogic
{
    class Program
    {
        private static decimal tax;

        static void Main(string[] args)
        {
            List<Slab> slabs = new List<Slab>();

            var listOfSlabs = File.ReadLines("taxSlabs.csv");

            foreach (var slab in listOfSlabs)
            {
                var row = slab.Split(',');
                if (row[0] == "MinValue")
                {
                    continue;
                }
                else
                {
                    slabs.Add(new Slab() { MinValue = int.Parse(row[0]), MaxValue = int.Parse(row[1]), TaxPercentage = decimal.Parse(row[2]) });
                }
            }

            Console.WriteLine("Enter Gross Salary");
            decimal salary;
            decimal.TryParse(Console.ReadLine(), out salary);


            var result = CalculateTax(slabs, salary);

            Console.WriteLine(result);
            Console.WriteLine("Income tax : " + Math.Round(tax, 2));
            Console.WriteLine("press any key to exit");
           
            Console.ReadKey();
        }

        public static decimal CalculateTax(List<Slab> slabs, decimal salary)
        {
           double income = Convert.ToDouble(salary);
            if (income <= 250000)
            {
                 tax = 0;
            }
            else if (income <= 500000)
            {
                tax = (decimal)((income - 250000) * 0.10);
            }
            else if (income <= 1000000)
            {
                 tax = (decimal)(12500 + (income - 500000) * 0.2);
            }
            else
            {
                 tax = (decimal)(112500 + (income - 1000000) * 0.3);
            }
            
            
            

            return tax;
        }
    }


    public class Slab
    {
        public int MinValue;
        public int MaxValue;
        public decimal TaxPercentage;
    }
}
